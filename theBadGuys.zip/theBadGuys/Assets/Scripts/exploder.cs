﻿using UnityEngine;
using System.Collections;

public class exploder : MonoBehaviour {

	public void turnOn()
	{
		
	}
	public void turnOff()
	{
	
	}
}
