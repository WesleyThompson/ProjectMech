﻿using UnityEngine;
using System.Collections;

public class ExplosionController : MonoBehaviour {

	public ParticleSystem explode;
	public GameObject enemy;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//if enemy is now dead, play death animation and start explosions
	}
}
