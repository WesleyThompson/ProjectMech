﻿#if UNITY_EDITOR

using UnityEngine;
using UnityEditor.Animations;
using UnityEditor;


public class AnimationHelper : EditorWindow {

	public GameObject target;
	public AnimationClip idleAnim;
	public AnimationClip walkAnim;
	public AnimationClip runAnim;

	[MenuItem ("Window/Animation Helper")]
	static void openWindow(){

		// Get existing open window or if none, make a new one
		GetWindow<AnimationHelper> ();
	}

	void onGUI(){
		target = EditorGUILayout.ObjectField ("Target Object", target, typeof(GameObject), true) as GameObject;
		idleAnim = EditorGUILayout.ObjectField ("Idle", idleAnim, typeof(AnimationClip), false) as AnimationClip;
		walkAnim = EditorGUILayout.ObjectField ("Walking", walkAnim, typeof(AnimationClip), false) as AnimationClip;
		runAnim = EditorGUILayout.ObjectField ("Running", runAnim, typeof(AnimationClip), false) as AnimationClip;

		if (GUILayout.Button ("Create")) {
			if (target == null) {
				Debug.LogError ("No target for animatior controller set.");
				return;
			}

			Create();
		}
	}

	void Create(){
		AnimatorController controller = AnimatorController.CreateAnimatorControllerAtPath ("Assests/" + target.name + ".controller");

		//adds a float parameter called speed
		controller.AddParameter("Speed", AnimatorControllerParameterType.Float);

		//Add states
		AnimatorState idleState = controller.layers[0].stateMachine.AddState("Idle");
		idleState.motion = idleAnim;

		//Blend Tree creation
		BlendTree blendTree;
		AnimatorState moveState = controller.CreateBlendTreeInController ("Move", out blendTree);

		//BlendTree setup
		blendTree.blendType = BlendTreeType.Simple1D;
		blendTree.blendParameter = "Speed";
		blendTree.AddChild (walkAnim);
		blendTree.AddChild (runAnim);

		AnimatorStateTransition leaveIdle = idleState.AddTransition (moveState);
		AnimatorStateTransition leaveMove = moveState.AddTransition (idleState);

		leaveIdle.AddCondition (AnimatorConditionMode.Greater, 0.01f, "Speed");
		leaveMove.AddCondition (AnimatorConditionMode.Less, 0.01f, "Speed");

		target.GetComponent<Animator> ().runtimeAnimatorController = controller;
	}
}#endif